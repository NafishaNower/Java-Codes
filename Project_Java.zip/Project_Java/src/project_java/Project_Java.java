//Project Name: Online movie ticket management system
//Group members: Nafisha Nower Juthi,2020-1-60-200
//Anuradha Roy,2020-1-60-206
//Rajia Bashir Rahi,2020-1-60-097
package project_java;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.*;


public class Project_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7;  
    JFrame s1;
    JFrame s2;
  
    ImageIcon img,img1, img2, img3, img4,img5; 
    JLabel a,im,im1,im2,im3,im4,im5;
    JButton b1;
    JButton b2;
    
    
    
        s1= new JFrame();  
       s2 = new JFrame();
       
       
        tf1=new JTextField("Welcome to Cineplex"); 
        tf1.setFont(new Font("Vrinda",Font.BOLD,20));
        tf1.setBounds(100,50,220,45);  
        tf2=new JTextField("Purchase Your Movie Ticket");
        tf2.setFont(new Font("Vrinda",Font.BOLD,20));
        tf2.setBounds(100,110,280,45); 
        
        img = new ImageIcon("C:\\Users\\pretty\\OneDrive\\Documents\\NetBeansProjects\\Project_Java\\img\\fr1.jpg");
        im = new JLabel(img);
        im.setBounds(200,170,550,550);
        
        a = new JLabel("Total seats of Hall");
        a.setFont(new Font("Vrinda",Font.BOLD,15));
        a.setBounds(480,25,150,50);

       
         tf3 = new JTextField("0");
        tf3.setBounds(500,60,80,20);
          tf4 = new JTextField("0");
        tf4.setBounds(500,75,80,20);
          tf5 = new JTextField("0");
        tf5.setBounds(500,90,80,20);
          tf6 = new JTextField("0");
        tf6.setBounds(500,105,80,20);
          tf7 = new JTextField("0");
        tf7.setBounds(500,120,80,20);
                  
        
        
        img1 = new ImageIcon("C:\\Users\\pretty\\OneDrive\\Documents\\NetBeansProjects\\Project_Java\\img\\frozen.jpg");
        im1 = new JLabel(img1);
        im1.setBounds(50,200,200,300);       
        img2 = new ImageIcon("C:\\Users\\pretty\\OneDrive\\Documents\\NetBeansProjects\\Project_Java\\img\\Tom & Jerry.jpg");
        im2 = new JLabel(img2);
        im2.setBounds(250,200,200,300);
        img3 = new ImageIcon("C:\\Users\\pretty\\OneDrive\\Documents\\NetBeansProjects\\Project_Java\\img\\raya.jpg");
        im3 = new JLabel(img3);
        im3.setBounds(440,200,150,300);
        img4 = new ImageIcon("C:\\Users\\pretty\\OneDrive\\Documents\\NetBeansProjects\\Project_Java\\img\\Harry.jpg");
        im4 = new JLabel(img4);
        im4.setBounds(590,200,180,300);
        img5 = new ImageIcon("C:\\Users\\pretty\\OneDrive\\Documents\\NetBeansProjects\\Project_Java\\img\\Toy story.jpg");
        im5 = new JLabel(img5);
        im5.setBounds(770,200,200,300);
       
       
       
          tf1.setEditable(false);
          tf2.setEditable(false);
        b1=new JButton("Next");
        b1.setFont(new Font("Vrinda",Font.BOLD,20));
        b1.setBounds(390,750,220,40);
        
        b2 = new JButton("Buy Ticket");
         b2.setFont(new Font("Vrinda",Font.BOLD,20));
        b2.setBounds(390,750,220,40);
        
         String data[][]={ {"Frozen 2","15/9/21","10:20 am","40","350tk"},    
                          {"Tom & Jerry","15/9/21","1:40 pm","40","350tk"},    
                          {"Raya The And Last Dragon","15/9/21","11:40 am","40","350tk"},
                          {"Harry Potter","15/9/21","2:40 pm","40","350tk"},
                          {"Toy Story 4","15/9/21","5:10 pm","40","350tk"},
                };
    String columns[]={"Movie Name","Date","Time","Seat Available","Amount"};        
    JTable jt=new JTable(data,columns);    
         
    JScrollPane sp=new JScrollPane(jt);  
        sp.setBounds(30,40,400,120);
        
             
       s2.add(sp);
       
        s1.add(b1);            
        s1.add(tf1);
        s1.add(tf2);
        s1.add(im);
       
       s2.add(b2);
       s2.add(a);

       s2.add(tf3);
       s2.add(tf4);
       s2.add(tf5);
       s2.add(tf6);
       s2.add(tf7);

       s2.add(im1);
       s2.add(im2);
       s2.add(im3);
       s2.add(im4);
       s2.add(im5);
       s2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
     
         s2.setSize(1000,900);  
        s2.setLayout(null);  
        s2.setVisible(true);
       
       
        s1.setSize(1000,900);  
        s1.setLayout(null);
        s1.setVisible(true);    
       
       
   b1.addActionListener(new ActionListener(){
       
       @Override
         public void actionPerformed(ActionEvent e) {
           
             s1.setVisible(false);         
    }
  });
   
    b2.addActionListener(new ActionListener(){


    @Override
         public void actionPerformed(ActionEvent e) {
            int in1 = 0;
            int in2 = 0;
            int in3 = 0;
            int in4 = 0;
            int in5 = 0;

             
             try {
     in1 = Integer.parseInt(tf3.getText());
     in2 = Integer.parseInt(tf4.getText());
     in3 = Integer.parseInt(tf5.getText());
     in4 = Integer.parseInt(tf6.getText());
     in5 = Integer.parseInt(tf7.getText());
 
}
catch(NumberFormatException ex)
{
    System.out.println("Exception : "+ex);
}
             int sum=(in1 +in2+in3+in4+in5)*350;
             JOptionPane.showMessageDialog(null, "Your Total Cost is :"+sum+"\n Thank u ");
             

    }
 });
    }
    
}
