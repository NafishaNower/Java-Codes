

//QUESTION:
/*Create a superclass named “Shapes” has a method “area()”. Subclasses of “Shapes” is “Triangle”, "Square" and “circle” .Each subclass has its formula of 
calculating area. Using Inheritance and Polymorphism, the subclasses can use the “area()” method to find the area’s formula and area for that shape.*/




/**
 *
 * @author Nafisha Nower Juthi
 */
package polimorphism.pkg1;
    class Shapes {    //super class
        double base,height,radius;
    public Shapes(double base,double height,double radius) {  //Contruction of class Shapes.
        this.base = base;
        this.height = height;
        this.radius=radius;
    }
  public void area() {       //method of class Shapes.
    System.out.println("The formula for area of: ");
  }
}




class Triangle extends Shapes {

    public Triangle(double base,double height,double radius) {   //Contruction of class Triangle.
        super(base, height,radius);
    }
    
    @Override   //overridden method area as class Triangle has extended class shapes.
  public void area() {
    System.out.println("Triangle is ½ * base * height ");
      System.out.println(0.5*base*height);
   }
  }



class Square extends Shapes {
double axis;
    public Square(double base,double height,double radius,double axis) {   //Contruction of class Triangle.
        super(base, height,radius);
        this.axis = axis;
    }
    
    @Override   //overridden method area as class Triangle has extended class shapes.
  public void area() {
    System.out.println("Square is axis*axis ");
      System.out.println(axis*axis);
   }
  }





class Circle extends Shapes {

    public Circle(double base,double height,double radius) {   //Contruction of class Circle.
        super(base, height, radius);
    }

    @Override
  public void area() {    ////overridden method area as class Circle has extended class shapes.
    System.out.println("Circle is 3.14 * radius * radius ");
      System.out.println(3.14 * radius * radius);
  }
}
    



    public class Polimorphism1 {  //main class.
    public static void main(String[] args) {
    Shapes Sha = new Shapes(3.0,4.0,5.0);  //object of class Shapes.
    Shapes Tri = new Triangle(4.0,5.0,6.0);  //object of class Triangle.   //polumorphism concept.
    Shapes Cir = new Circle(6.0,7.0,8.0);   //object of class Circle.
    Shapes Sqr=new Square(9.0,10.0,3.0,4.0);  //object of class Square.
    Sha.area();
    Tri.area();
    Sha.area();
    Cir.area();     //calling method.
   Sha.area();
    Sqr.area();
    }
    
}



