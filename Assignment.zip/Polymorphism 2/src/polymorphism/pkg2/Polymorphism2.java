
//QUESTION:
/*Create a superclass named “Animal” has a method “sound()”. Subclasses of “Animals” are “Cat”, "Snake" and “Bird” .Each subclass has its own sound.
Using Inheritance and Polymorphism, the subclasses can use the “sound()” method to find the sound of every animal.*/





/**
 *
 * @author Nafisha Nower Juthi
 */

package polymorphism.pkg2;
 class Animal{  //super class.
   public void sound(){
      System.out.println("Animal is making a sound");   
   }
}



class Snake extends Animal{
    @Override
    public void sound(){  //overridden method sound as class Snake has extended class Animal.
        System.out.println("shshsh");
    }}



 class Cat extends Animal{
    @Override
    public void sound(){    //overridden method sound as class Cat has extended class Animal.
        System.out.println("Meow");
    }}



class Bird extends Animal{
    @Override
    public void sound(){    //overridden method sound as class Bird has extended class Animal.
        System.out.println("chew chew");
    }}




public class Polymorphism2 {
    public static void main(String[] args) {
        Animal anim1 = new Cat();  ///object of class Cat.
    	   System.out.print("Sound of Cat:");
           anim1.sound();
        Animal anim2 = new Snake(); //object of class Snake.     //polymorphism concept.
        System.out.print("Sound of Snake:");
    	anim2.sound();
        Animal anim3=new Bird();   //object of class Bird.
        System.out.print("Sound of Bird:");
        anim3.sound();//calling method
    }
    
}
