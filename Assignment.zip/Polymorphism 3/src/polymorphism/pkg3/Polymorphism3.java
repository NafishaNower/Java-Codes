//QUESTION:
/*Create a superclass named “PhoneNumber” has a method “StartDigit()”. Subclasses of “Bangladesh” are “India”, "Pakistan" and “America” .
Each subclass has its own Start digit of phone number.
Using Inheritance and Polymorphism, the subclasses can use the “StarDigit()” method to find the number start digit of every country.*/




/**
 *
 * @author Nafisha Nower Juthi
 */
package polymorphism.pkg3;
class PhoneNumber{    //super class.
    void StartDigit(){  
        System.out.println("This is a list of starting phone number digits of Bangladesh India Pakistan America:");
    }
}



class Bangladesh extends PhoneNumber{
    void StartDigit(){  //overridden method StartDigit as class Bangladesh has extended class PhoneNumber.
        System.out.println("Bangladesh : +880");
    }
}



class India extends PhoneNumber{
    void StartDigit(){    //overridden method StartDigit as class India has extended class PhoneNumber.
        System.out.println("India : +91");
    }
}




class Pakistan extends PhoneNumber{
    void StartDigit(){       //overridden method StartDigit as class Pakistan has extended class PhoneNumber.
        System.out.println("Pakistan : +92");
    }
}




class America extends PhoneNumber{
    void StartDigit(){    //overridden method StartDigit as class America has extended class PhoneNumber.
        System.out.println("America : +1");
    }
}





public class Polymorphism3 {
    public static void main(String[] args) {
       PhoneNumber bd = new Bangladesh();   //object of class Bangladesh.
        PhoneNumber in = new India();     //object of class India.
         PhoneNumber pak = new Pakistan();    //object of class Pakistan.   //polymorphism concept.
          PhoneNumber usa = new America();     //object of class America.
           PhoneNumber pn = new PhoneNumber();    //object of class PhoneNumber.
           pn.StartDigit();
          bd.StartDigit();
          in.StartDigit();  //calling method.
          pak.StartDigit();
          usa.StartDigit();
           
    }
    
}
